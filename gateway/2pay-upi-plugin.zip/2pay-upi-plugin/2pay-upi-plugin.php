<?php
/*
Plugin Name: 2Pay UPI Plugin
Description: UPI payment plugin for WordPress.
Author: Ladhani Enterprises (Mauritius) Ltd
Version: 1.0.1
*/

// Create custom database table during plugin activation
function create_upi_settings_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . '2pay_upi_plugin_settings';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        ip VARCHAR(100),
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        pid VARCHAR(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'create_upi_settings_table');

// Add shortcode to display the UPI payment form
function upi_payment_form_shortcode() {
    ob_start();
    $order_id = rand(999, 99999);
    global $wpdb;
    $table_name = $wpdb->prefix . '2pay_upi_plugin_settings';
    $ip = $_SERVER['REMOTE_ADDR'];
    $pid_entry = $wpdb->get_row("SELECT pid FROM $table_name WHERE ip = '$ip' ORDER BY id DESC LIMIT 1");

    if ($pid_entry) {
        $pid = $pid_entry->pid;

        // Define the form submit url
        $form_url = "https://2pay.infomattic.com/init_payment.php";
        ?>

        <form method="post" action="<?php echo $form_url; ?>" style="margin-top: 20px;">
            <label for="purpose">Purpose of Payment</label><br>
            <input type="text" name="purpose" id="purpose" placeholder="Purpose of payment" style="width: 100%;" required /><br><br>
            <label for="amt">Amount</label><br>
            <input type="text" name="amt" id="amt" placeholder="Enter amount" style="width: 100%;" required /><br><br>
            <label for="name">Your Full Name</label><br>
            <input type="text" name="name" id="name" placeholder="Your full name" style="width: 100%;" required /><br><br>
            <label for="phone">Phone Number</label><br>
            <input type="text" name="phone" id="phone" placeholder="Your phone number" style="width: 100%;" required /><br><br>
            <label for="email">Email</label><br>
            <input type="email" name="email" id="email" placeholder="Your email id" style="width: 100%;" required /><br><br>
            <input type="hidden" name="order_id" value="<?php echo "2PAY" . date('Ymd') . $order_id; ?>" />
            <input type="hidden" name="pid" value="<?php echo $pid; ?>" />
            <input type="submit" name="submit" value="Make Payment" style="background-color: #5728a8; color: #fff; border: none; padding: 10px 20px; cursor: pointer; margin-top: 10px; width: 100%;">
        </form>

        <p>* This form is powered by <a href="https://2pay.infomattic.com/register.php" target="_blank">2Pay UPI Gateway</a>. UPI / NEFT / IMPS / RTGS payments accepted.</p>
        <?php
    } else {
        echo 'Oopss! It looks like the Merchant ID has not been set yet.';
    }

    return ob_get_clean();
}
add_shortcode('upi_payment_form', 'upi_payment_form_shortcode');

// Handle UPI payment form submission
function handle_upi_payment_submission() {
    if (isset($_POST['submit'])) {
        // Fetch the data from POST
        //$order_id = sanitize_text_field($_POST['order_id']);
        //$pid = sanitize_text_field($_POST['pid']);
        //$purpose = sanitize_text_field($_POST['purpose']);
        //$amt = floatval($_POST['amt']);
        //$name = sanitize_text_field($_POST['name']);
        //$phone = sanitize_text_field($_POST['phone']);
        //$email = sanitize_email($_POST['email']);

        # Perform validation and initiate payment processing here

        // Redirect to a thank you page after successful payment
        //wp_redirect('thank_you_page_link');
        //exit();
    }
}
add_action('init', 'handle_upi_payment_submission');

// Add plugin settings
function upi_plugin_settings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . '2pay_upi_plugin_settings';

    if (isset($_POST['submit_pid'])) {
        $pid = sanitize_text_field($_POST['2pay_upi_pid']);
        $ip = $_SERVER['REMOTE_ADDR'];
        // Delete existing entries for this IP
        $wpdb->delete($table_name, array('ip' => $ip));
        // Insert new PID entry
        $wpdb->insert($table_name, array('pid' => $pid, 'ip' => $ip));
    }

    $pids = $wpdb->get_results("SELECT pid FROM $table_name WHERE ip = '" . $_SERVER['REMOTE_ADDR'] . "'");
    ?>

    <div class="wrap">
        <div style="background-color: #fff; border-left: 3px solid #5728a8; padding: 10px; border-radius: 5px; margin-top: 25px; margin-bottom: 25px;">
            <p style="font-size: 16px; font-weight: bold;">2Pay UPI Plugin Settings</p>
            <p style="font-size: 15px; line-height: 1.8em;">* To begin accepting live payments, save your 2Pay Merchant ID. If you're an existing 2Pay user, simply log in to your dashboard, navigate to the profile section, scroll down to api credentials and copy the Merchant ID. Then, paste it here to save. If you're new to 2Pay, you can <a href="https://2pay.infomattic.com/register.php" target="_blank">sign up for an account</a>.</p>
            <p style="font-size: 15px; line-height: 1.8em;">* To display the payment form, just create a page and insert the shortcode <strong>[upi_payment_form]</strong>. You can use this shortcode on any page where you wish to showcase the payment form.</p>
            <p style="font-size: 15px; line-height: 1.8em;">* You have the ability to view and manage both the form data and payments directly from your <a href="https://2pay.infomattic.com/login.php" target="_blank">2Pay merchant dashboard</a>.</p>               
        </div> 

        <div style="background-color: #fff; border-left: 3px solid #5728a8; padding: 10px; border-radius: 5px; margin-top: 25px; margin-bottom: 25px;">
            <form method="post" action="" style="margin-top: 20px;">
                <p style="font-size: 16px; font-weight: bold;">Merchant ID</p>
                <input type="text" name="2pay_upi_pid" id="2pay_upi_pid" placeholder="Enter Merchant ID" /><br>
                <input type="submit" name="submit_pid" value="Submit" style="background-color: #5728a8; color: #fff; border: none; padding: 10px 20px; cursor: pointer; margin-top: 15px; border-radius: 5px; margin-bottom:15px">
            </form>
        </div>

        <div style="background-color: #fff; border-left: 3px solid #5728a8; padding: 10px; border-radius: 5px; margin-top: 25px; margin-bottom: 25px;">
            <p style="font-size: 16px; font-weight: bold;">Saved Merchant ID</p>
            <ul>
                <?php foreach ($pids as $entry) : ?>
                    <li><?php echo esc_html($entry->pid); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <?php
}
add_action('admin_menu', 'add_upi_plugin_settings_page');

// Add settings link on plugin page
function upi_plugin_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=2pay-upi-plugin-settings">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'upi_plugin_settings_link');

// Display plugin settings page
function add_upi_plugin_settings_page() {
    add_submenu_page(
        'options-general.php',
        '2Pay UPI Plugin Settings',
        '2Pay UPI Settings',
        'manage_options',
        '2pay-upi-plugin-settings',
        'upi_plugin_settings_page'
    );
}

// Register deactivation hook to remove the custom database table
function delete_upi_settings_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . '2pay_upi_plugin_settings';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
register_deactivation_hook(__FILE__, 'delete_upi_settings_table');

?>
